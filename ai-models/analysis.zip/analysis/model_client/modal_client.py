"""HTTP client for Modal-hosted CV analysis."""

from __future__ import annotations

import logging
import re
import time
from typing import Any, Optional
from urllib.parse import parse_qs, urlparse

import httpx

from analysis.config import (
    MODAL_ENDPOINT_URL,
    MODAL_MAX_NEW_TOKENS,
    MODAL_POLL_TIMEOUT,
    MODAL_POST_TIMEOUT,
)
from analysis.model_client.prompts import normalize_target_role

log = logging.getLogger("analysis")

_MODAL_WEB_BLOCK_S = 155.0
_POLL_RETRY_SLEEP_S = 1.0
_CALL_ID_RE = re.compile(r"__modal_function_call_id=([^&]+)")


def _extract_function_call_id(result_url: str) -> Optional[str]:
    query = parse_qs(urlparse(result_url).query)
    ids = query.get("__modal_function_call_id")
    if ids:
        return ids[0]
    match = _CALL_ID_RE.search(result_url)
    return match.group(1) if match else None


def _poll_modal_function_call(call_id: str, timeout_s: float) -> Optional[dict[str, Any]]:
    """Poll via Modal SDK — avoids 150s HTTP redirect loops on long GPU cold starts."""
    try:
        import modal
    except ImportError:
        log.warning("modal package not installed — falling back to HTTP polling")
        return None

    try:
        log.info("Polling Modal function call %s (up to %ss)", call_id, int(timeout_s))
        result = modal.FunctionCall.from_id(call_id).get(timeout=timeout_s)
    except TimeoutError:
        log.warning("Modal function call %s timed out after %ss", call_id, int(timeout_s))
        return None
    except Exception as exc:
        log.warning("Modal function call %s failed: %s", call_id, exc)
        return None

    if not isinstance(result, dict):
        log.warning("Modal function call returned unexpected type: %s", type(result).__name__)
        return None
    return result


def _poll_modal_result_url(
    client: httpx.Client,
    result_url: str,
    deadline: float,
) -> Optional[dict[str, Any]]:
    """HTTP fallback when Modal SDK polling is unavailable."""
    attempt = 0
    while time.monotonic() < deadline:
        attempt += 1
        remaining = max(1.0, deadline - time.monotonic())
        request_timeout = min(remaining, _MODAL_WEB_BLOCK_S)
        try:
            resp = client.get(result_url, timeout=request_timeout)
        except httpx.TimeoutException:
            if time.monotonic() < deadline:
                log.info(
                    "Modal HTTP poll attempt %d timed out after %.0fs — retrying",
                    attempt,
                    request_timeout,
                )
                continue
            log.warning("Timed out polling Modal result URL after %d attempts", attempt)
            return None
        except httpx.RequestError as exc:
            log.warning("Could not poll Modal result URL: %s", exc)
            return None

        if resp.status_code == 200:
            try:
                return resp.json()
            except ValueError:
                log.warning("Modal result URL returned non-JSON body")
                return None

        if resp.status_code in (202, 303):
            location = resp.headers.get("location")
            if location:
                result_url = location
            log.info(
                "Modal HTTP poll attempt %d: HTTP %s — still running",
                attempt,
                resp.status_code,
            )
            if time.monotonic() >= deadline:
                break
            time.sleep(_POLL_RETRY_SLEEP_S)
            continue

        log.warning(
            "Modal poll returned HTTP %s: %s",
            resp.status_code,
            resp.text[:300],
        )
        return None

    log.warning(
        "Modal HTTP polling exceeded deadline (%ss, %d attempts)",
        MODAL_POLL_TIMEOUT,
        attempt,
    )
    return None


def _poll_modal_result(
    client: httpx.Client,
    result_url: str,
    poll_deadline: float,
) -> Optional[dict[str, Any]]:
    call_id = _extract_function_call_id(result_url)
    if call_id:
        remaining = max(1.0, poll_deadline - time.monotonic())
        data = _poll_modal_function_call(call_id, remaining)
        if data is not None:
            return data
        log.info("Modal SDK poll unavailable/failed — falling back to HTTP polling")

    return _poll_modal_result_url(client, result_url, poll_deadline)


def _call_dedicated_endpoint(
    resume_text: str,
    max_new_tokens: int,
    target_role: str = "",
) -> Optional[dict]:
    payload: dict = {
        "resume_text": resume_text,
        "max_new_tokens": max_new_tokens,
    }
    role = normalize_target_role(target_role)
    if role:
        payload["target_role"] = role

    url = MODAL_ENDPOINT_URL.rstrip("/")
    poll_deadline = time.monotonic() + MODAL_POLL_TIMEOUT

    try:
        with httpx.Client(follow_redirects=False) as client:
            try:
                resp = client.post(
                    url,
                    json=payload,
                    headers={"Content-Type": "application/json"},
                    timeout=MODAL_POST_TIMEOUT,
                )
            except httpx.TimeoutException:
                log.warning("Modal POST timed out after %ss", MODAL_POST_TIMEOUT)
                return None
            except httpx.RequestError as exc:
                log.warning("Could not reach analysis endpoint: %s", exc)
                return None

            if resp.status_code == 200:
                data = resp.json()
            elif resp.status_code == 303:
                location = resp.headers.get("location")
                if not location:
                    log.warning("Modal returned 303 without Location header")
                    return None
                log.info("Modal returned 303 — waiting for GPU result (up to %ss)", MODAL_POLL_TIMEOUT)
                data = _poll_modal_result(client, location, poll_deadline)
                if data is None:
                    return None
            else:
                log.warning(
                    "Analysis endpoint returned HTTP %s: %s",
                    resp.status_code,
                    resp.text[:300],
                )
                return None
    except Exception as exc:
        log.warning("Analysis endpoint call failed: %s", exc)
        return None

    if "error" in data:
        log.warning("Analysis endpoint returned an error: %s", data["error"])
        return None

    if not data.get("parsed"):
        log.warning("Analysis endpoint did not return parsable JSON")
        return None

    return data


def call_analysis_model(
    resume_text: str,
    max_new_tokens: int = MODAL_MAX_NEW_TOKENS,
    target_role: str = "",
) -> Optional[dict]:
    """Returns {"raw": "...", "parsed": {...}} on success, or None on failure."""
    if MODAL_ENDPOINT_URL:
        return _call_dedicated_endpoint(resume_text, max_new_tokens, target_role)

    log.error("No analysis endpoint configured — set MODAL_ENDPOINT_URL in .env")
    return None
